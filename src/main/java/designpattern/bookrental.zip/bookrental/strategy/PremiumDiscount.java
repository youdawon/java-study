package designpattern.bookrental.strategy;

public class PremiumDiscount implements DiscountStrategy{

  @Override
  public double discount(double price) {
    return price - price * 0.1;
  }
}
