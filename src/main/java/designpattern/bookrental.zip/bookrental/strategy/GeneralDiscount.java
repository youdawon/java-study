package designpattern.bookrental.strategy;

public class GeneralDiscount implements DiscountStrategy{

  @Override
  public double discount(double price) {
    return price;
  }
}
