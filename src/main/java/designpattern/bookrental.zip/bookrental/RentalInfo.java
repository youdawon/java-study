package designpattern.bookrental;

import java.time.LocalDate;

public class RentalInfo {

  private String bookId;
  private LocalDate expirationDate;
}
