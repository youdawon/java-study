package designpattern.bookrental.model.enums;

public enum MemberLevel {
  REGULAR,
  PREMIUM,
  VIP
}
